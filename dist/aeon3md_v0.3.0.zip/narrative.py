import aeon3md
import sys

aeon3md.main(sys.argv[1], '_full_synopsis')
